#Перед использованием MeemMc Python API ознакомтесь с правилами https://yadi.sk/i/TaYW1YGWGpacMw
#Начало кода
print('MeemMc крутой сервер minecraft')
print('VK - vk.com/meemmc')
